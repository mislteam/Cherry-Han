<?php

namespace App\Http\Controllers\Container;

use App\Http\Controllers\Controller;
use App\Models\ContainerBooking;
use Illuminate\Http\Request;

class ContainerBookingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ContainerBooking  $containerBooking
     * @return \Illuminate\Http\Response
     */
    public function show(ContainerBooking $containerBooking)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ContainerBooking  $containerBooking
     * @return \Illuminate\Http\Response
     */
    public function edit(ContainerBooking $containerBooking)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ContainerBooking  $containerBooking
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ContainerBooking $containerBooking)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ContainerBooking  $containerBooking
     * @return \Illuminate\Http\Response
     */
    public function destroy(ContainerBooking $containerBooking)
    {
        //
    }
}
