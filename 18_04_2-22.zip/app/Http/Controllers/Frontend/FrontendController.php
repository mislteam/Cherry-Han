<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Car;
use App\Models\Cargo;
use App\Models\Container;
use App\Models\Tour;
use App\Models\Hotel;
use App\Models\BusTicket;
use App\Models\City;
use App\Models\State;
use App\Models\HotelRoomType;
use App\Models\TourItineary;
use Illuminate\Support\Facades\DB;
use App\Services\LogWriter;
use App\Models\ApiUser;
use Session;



class FrontendController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {         
        $cars = Car::all();                
        return view('frontend.cars',compact('cars'));
    }
    public function registeradd()
    {         
        $cities = City::all();                
        $states = State::all();                
        return view('frontend.user-register.add',compact('cities','states'));
    }


    public function carindex()
    {
       $cars = Car::all();                
       return view('frontend.cars',compact('cars'));
    }

    public function tourindex()
    {
       $tours = Tour::all();                
        return view('frontend.tours',compact('tours'));
    }
    public function hotelindex()
    {
       $hotels = Hotel::all();                
        return view('frontend.hotel',compact('hotels'));
    }

    public function busticketindex()
    {
       $bustickets = BusTicket::all();                
        return view('frontend.busticket',compact('bustickets'));
    }
    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function getweight($city_id)
    {
        //$city_id = $request->city_id;
         $data = DB::table('delivery_charges')
            ->where('city_id',$city_id)
            ->get();
        echo json_encode($data);   
    }

    public function registercreate(Request $request)
    {
               
        $api_user = ApiUser::create([
            'name'          => $request->name,
            'phone'      => $request->phone,
            'email'      => $request->email,
            'state_id'   => $request->state_id,
            'city_id'    => $request->city_id,
            'address'    => $request->address,
            'password'   => $request->confirm_password,
            'created_by' => rand(1,999),
            'status' => 'user',           
        ]);

        $rand=rand(1,999999);
        Session::put('randomkey', $rand);


        $activity = "\nCreated by: ".json_encode(auth()->user())."\nNew Apiuser: ".json_encode($api_user);

        LogWriter::user_activity($activity,'Addingapiuser');
     
        return redirect()->route('verifyformAdd');
        
    }

    public function verifyform()
    {
        return view('frontend.user-register.verifyform');
    }

    public function verificationCreate()
    {
        session()->forget('randomkey');
        return redirect()->route('verifyformAdd');
    }

    public function containerindex()
    {
       $containers = Container::all();                
       return view('frontend.container', compact('containers'));
    }

    public function cargoindex()
    {
       $cargos = cargo::all();                
       return view('frontend.cargo', compact('cargos'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function carview($id)
    {
        //
        $car = Car::find($id);
        return view('frontend.carview_detail', compact('car'));
    }

    public function containerview($id)
    {
        //
        $container = Container::find($id);
        return view('frontend.containerview_detail', compact('container'));
    }

    public function cargoview($id)
    {
        //
        $cargo = Cargo::find($id);
        return view('frontend.cargoview_detail', compact('cargo'));
    }

    public function tourview($id)
    {
        //
        $itineary=TourItineary::where('tour_id',$id)->get();
        $tour = Tour::find($id);
        return view('frontend.tourview_detail', compact('tour','itineary'));
    }
     public function hotelview($id)
    {
        $roomtypes=HotelRoomType::where('hotel_id',$id)->get();
        $hotel = Hotel::find($id);
        return view('frontend.hotelview_detail', compact('hotel','roomtypes'));
    }

     public function getstatecity(Request $request) {
        $state_id = $request->state_id;
         $data = DB::table('cities')
             ->where('state_id',$state_id)
            ->get();
        
            echo json_encode($data);       
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
