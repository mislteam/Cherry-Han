<?php

namespace App\Http\Controllers\Blade;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\LogWriter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AjaxController extends Controller
{

    public function getstatecity(Request $request) {
        abort_if_forbidden('user.show');
        $state_id = $request->state_id;
        $data = DB::table('cities')
            ->where('state_id',$state_id)
            ->get();
        
        echo json_encode($data);       
    }
    
    public function getcountrystate(Request $request) {
        abort_if_forbidden('user.show');
        $country_id = $request->country_id;
        $data = DB::table('states')
            ->where('country_id', $country_id)
            ->get();
        
        echo json_encode($data);       
    }

    // user add page

}
