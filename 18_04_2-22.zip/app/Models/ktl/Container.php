<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Container extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'brand_id',
        'model_id',
        'width',
        'height',
        'capacity',
        'trip_type',
        'day_type',
        'city_id',
        'state_id',
        'country_id',
        'car_type_id',
        'ac',
        'abs',
        'wheel_drive',
        'license_type',
        'service',
        'driver_id',
        'ownner_id',
        'feature_photo',
        'gallery',
        'booking_status',
        'booking_for',
        'status',
    ];
}
