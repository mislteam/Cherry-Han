<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Hotel extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'price',
        'feature_image',
        'phone',
        'email',
        'website',
        'address',
        'description',
        'gallery',
        'localtion_id',
        'star_level',
        'service',
        'status',
        'created_by',
    ];
    public function state()
    {
        return $this->hasOne(State::class, 'id', 'localtion_id');
    }
}
