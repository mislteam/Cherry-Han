<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    use HasFactory;
    protected $fillable=[
        'subject',
        'description',
        'msg_from',
        'msg_to',
        'read_status',
        'file',
        'status',
        'created_by',        
         
    ];
    public function apiuserto()
    {
        return $this->hasOne(ApiUser::class,'id','msg_to');
    }
    public function apiuserfrom()
    {
        return $this->hasOne(ApiUser::class,'id','msg_from');
    }
}
