<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cargo extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'model_id',
        'brand_id',
        'width',
        'height',
        'user_id',
        'trip_type',
        'day_type',
        'city_id',
        'state_id',
        'country_id',
        'seat_no',
        'ac',
        'abs',
        'wheel_drive',
        'no_of_laggage',
        'service',
        'driver_info',
        'feature_info',
        'photo',
        'status',
    ];
}
