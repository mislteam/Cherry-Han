
<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1></h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->

    <section class="content">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"><?php echo app('translator')->get('global.add'); ?></h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">

                        <form action="<?php echo e(route('cardriverCreate')); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>Name </label>
                                        <input id="name" name="name" type="text" class="form-control">                                    
                                    </div>   
                                    <div class="form-group">
                                        <label>Phone </label>
                                        <input id="phone" name="phone" type="text" class="form-control">                                    
                                    </div>
                                    <div class="form-group">
                                        <label>Email </label>
                                        <input id="email" name="email" type="email" class="form-control">                                    
                                    </div>  
                                    <div class="form-group">
                                        <label>Age </label>
                                        <input id="age" name="age" type="text" class="form-control">                                    
                                    </div> 
                                    <div class="form-group">
                                        <label>Gender </label>
                                        <select  name="gender" class="form-control" placeholder="gender">
                                            <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>                                    
                                    </div>
                                    <div class="form-group">
                                        <label>License Type </label>
                                        <input id="license_type" name="license_type" type="text" class="form-control">                                       
                                    </div>   
                                                           
                                </div>
                                <div class="col-lg-6">               
                                    <div class="form-group">
                                        <label>Address </label>
                                        <input id="address" name="address" type="text" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Tour Exp </label>
                                        <input id="tour_exp" name="tour_exp" type="text" class="form-control">                                    
                                    </div> 
                                    <div class="form-group">
                                        <label>Drive Exp </label>
                                        <input id="drive_exp" name="drive_exp" type="text" class="form-control">                                    
                                    </div> 
                                    <div class="form-group">
                                        <label>City</label>
                                        <select  name="city_id" class="form-control" placeholder="<?php echo app('translator')->get('form.car.city_id.placeholder'); ?>">
                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>      
                                    <div class="form-group">
                                        <label>Country</label>
                                        <select  name="country_id" class="form-control" placeholder="<?php echo app('translator')->get('form.car.country_id.placeholder'); ?>">
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>State</label>
                                        <select  name="state_id" class="form-control" placeholder="<?php echo app('translator')->get('form.car.state_id.placeholder'); ?>">
                                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div> 
                            <div class="form-group">
                                <button type="submit" class="btn btn-success float-right"><?php echo app('translator')->get('global.save'); ?></button>
                                <a href="<?php echo e(route('carownerIndex')); ?>" class="btn btn-default float-left"><?php echo app('translator')->get('global.cancel'); ?></a>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cherryhan\resources\views/pages/cardriver/add.blade.php ENDPATH**/ ?>