<?php $__env->startSection('content'); ?>
        <!-- Main content -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5><?php echo translate('delivery_service'); ?></h5>
                            
                        </div>
                        <div class="ibox-content">
                            <?php $segment1 = Request::segment(1); ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover dataTables-<?php echo e($segment1); ?>" >
                                    <thead>
                                        <tr>
                                            <th class="text-center"><?php echo translate('id') ?></th>
                                            <th class="text-center"><?php echo translate('sender_name') ?></th>
                                            <th class="text-center"><?php echo translate('sender_phone') ?></th>
                                            <th class="text-center"><?php echo translate('receiver_name') ?></th>
                                            <th class="text-center"><?php echo translate('receiver_phone') ?></th>
                                            <th class="text-center"><?php echo translate('pickup_township') ?></th>
                                            <th class="text-center"><?php echo translate('delivery_township') ?></th>
                                            <th class="text-center"><?php echo translate('weight') ?></th>
                                            <th class="text-center"><?php echo translate('delivery_charges') ?></th>
                                            <th class="text-center"><?php echo translate('address') ?></th>
                                            <th class="text-center"><?php echo translate('note') ?></th>
                                            <!-- <th class="text-center"><?php echo translate('message') ?></th> -->
                                            <th class="text-center"><?php echo translate('action') ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $count = 1;
                                    ?>
                                    <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-right"><?php echo e($count); ?></td>
                                            
                                            <td><?php echo e($row->sender_name); ?></td>
                                            <td><?php echo e($row->sender_phone); ?></td>
                                            <td><?php echo e($row->receiver_name); ?></td>
                                            <td><?php echo e($row->receiver_phone); ?></td>
                                            <td><?php echo e($row->pickuptownship->name); ?></td>
                                            <td><?php echo e($row->deliverytownship->name); ?></td>
                                            <td><?php echo e($row->weight); ?></td>
                                            <td><?php echo e($row->del_charges); ?></td>
                                            <td><?php echo e($row->detail_address); ?></td>

                                            <td><?php echo e($row->note); ?></td>
                                           
                                            <td>
                                                <div class="dropdown">
                                                  <button class="btn btn-cherryhan dropdown-toggle" type="button" data-toggle="dropdown"><?php echo e(ucwords($row->status)); ?>

                                                  </button>
                                                  <ul class="dropdown-menu">
                                                    
                                                    <?php 
                                                    $status=delivery_status();

                                                    $ind=count($status);
    
        
                                                    $info=json_decode($row->status_info,true); 
                                                    unset($status[4]);
                                                    if(in_array('shipping', $info)){
                                                        $status[$ind]='completed';
                                                        unset($status[5]);
                                                        //print_r($status); 
                                                    }
   
                                                    ?>
                                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   
                                                    <?php 
                                                    if(!in_array($s,$info)){
                                                        /*if(in_array('shipping',$info)){*/
                                                        ?>
                                                    <li><a href="<?php echo e(URL('/delivery-booking/'.$row->id.'/'.$s)); ?>" class="btn btn-cherryhan"><?php echo e(ucwords($s)); ?></a></li>

                                                    <?php  } ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                   
                                                    
                                                  </ul>
                                                </div>
                                            </td>
                                            
                                            
                                            
                                        </tr>
                                        <?php
                                        $count++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <!-- /.content -->
<?php $__env->stopSection(); ?>
<!-- 
<script src="<?php echo e(asset('misl/back/js/jquery.min.js')); ?>"></script>

<script type="text/javascript">
     function delivery_status(id,status){
        alert(status);
            $.ajax({
                url: "/delivery-booking/"+id+"/"+status,
                type: "get",
                dataType: "json",
                success: function(result){
                   
                    if (result.status == 'collected'){
                        $("#d_status"+id).val('collected');
                        //window.location = "/delivery-booking/delivery-service";
                        //location.reload();
                    }
                  
                },
                error: function (errorMessage){
                    console.log(errorMessage)
                }
            });
        }
</script> -->



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cherryhan\resources\views/pages/delivery/delivery_booking.blade.php ENDPATH**/ ?>