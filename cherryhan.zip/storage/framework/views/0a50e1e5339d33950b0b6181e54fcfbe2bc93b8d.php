<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo app('translator')->get('form.category.title'); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('global.home'); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('roleIndex')); ?>"><?php echo app('translator')->get('cruds.category.title'); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo app('translator')->get('global.add'); ?></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->

    <section class="content">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"><?php echo app('translator')->get('form.sub_category.title_edit'); ?></h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">

                        <form action="<?php echo e(route('sub_categoryUpdate', $subcategory->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label><?php echo app('translator')->get('form.sub_category.name.label'); ?></label>
                                <input type="text" name="name" placeholder="<?php echo app('translator')->get('form.sub_category.name.placeholder'); ?>" class="form-control" value="<?php echo e(old('name', $subcategory->name)); ?>">
                            </div>
                            <div class="form-group">
                                <label><?php echo app('translator')->get('form.sub_category.category_id.label'); ?></label>
                                <select  name="category_id" class="form-control" placeholder="<?php echo app('translator')->get('form.sub_category.category_id.placeholder'); ?>">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php echo e(($category->id == $subcategory->category_id)?'checked':''); ?>><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label><?php echo app('translator')->get('form.sub_category.slug.label'); ?></label>
                                <input type="text" name="slug" placeholder="<?php echo app('translator')->get('form.sub_category.slug.placeholder'); ?>" class="form-control" value="<?php echo e(old('slug', $subcategory->slug)); ?>">
                            </div>
                            <div class="form-group ">
                                <button type="submit" class="btn btn-success float-right ml-3"><?php echo app('translator')->get('global.save'); ?></button>
                                <a href="<?php echo e(route('roleIndex')); ?>" class="btn btn-default float-right"><?php echo app('translator')->get('global.cancel'); ?></a>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_tut\cherryhan\resources\views/pages/sub_category/edit.blade.php ENDPATH**/ ?>