<?php $__env->startSection('content'); ?>
        <!-- Main content -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5><?php echo translate('agents_list'); ?></h5>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agent.add')): ?>
                                <div class="ibox-tools">
                                    <a href="<?php echo e(route('agentAdd')); ?>" class="btn btn-sm pt-2 btn-cherryhan" ><i class="fa fa-plus-circle"></i> <?php echo translate('add_new'); ?></a>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="ibox-content">
                            <?php $segment1 = Request::segment(1); ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover dataTables-<?php echo e($segment1); ?>" >
                                    <thead>
                                        <tr>
                                            <th class="text-center"><?php echo translate('id') ?></th>
                                            <th><?php echo translate('agent_name') ?></th>
                                            <th><?php echo translate('agent_phone') ?></th>
                                            <th><?php echo translate('agent_email') ?></th>
                                            <th><?php echo translate('agent_address') ?></th> 
                                            <th><?php echo translate('created_by') ?></th>
                                            <th><?php echo translate('status') ?></th>
                                            <th class="text-center"><?php echo translate('action') ?></th>
                                        </tr>

                                    </thead>
                                    <tbody>
                                    <?php
                                    $count = 1;
                                    ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center">
                                        <td class="text-right"><?php echo e($count); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->phone); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->address); ?></td>
                                        <td><?php echo e($user->creator->name ?? '-'); ?></td>
                                        <td class="text-center">
                                            <i style="cursor: pointer" id="api_user_<?php echo e($user->id); ?>" class="fa <?php echo e(($user->is_active) ? 'fa-check-circle text-info':'fa-times-circle text-danger'); ?>"
                                               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("customer.edit")): ?> onclick="toggle_api_user(<?php echo e($user->id); ?>)" <?php endif; ?> ></i>
                                        </td>
                                        <td class="text-center">
                                            <form action="<?php echo e(route('apiuserDestroy',$user->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="btn-group">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agent.edit')): ?>
                                                        <a href="<?php echo e(route('apiuserShow',$user->id)); ?>" type="button" class="btn btn-success btn-sm"><i class="fa fa-eye"></i></a>
                                                    <?php endif; ?>
                                                    
                                                    <input name="_method" type="hidden" value="DELETE">
                                                    <button type="button" class="btn btn-danger btn-sm" onclick="if (confirm('Вы уверены?')) { this.form.submit() } "><i class="fa fa-trash"></i></button>
                                                </div>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fwsdemop/public_html/cherryhan/resources/views/pages/agent/index.blade.php ENDPATH**/ ?>