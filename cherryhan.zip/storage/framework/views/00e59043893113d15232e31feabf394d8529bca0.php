

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox col-lg-6 mx-auto">
                <div class="ibox-title">
                    <h5><?php echo translate('add_new_bus_ticket'); ?></h5>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('car.view')): ?>
                        <div class="ibox-tools">
                            <a href="<?php echo e(route('busticketIndex')); ?>" class="btn btn-sm pt-2 btn-cherryhan" go-to-back ><i class="fa fa-reply"></i> <?php echo translate('back'); ?></a>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="ibox-content">
                    <form action="<?php echo e(route('busticketCreate')); ?>" method="POST" accept-charset="utf-8" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="form-group row <?php echo e($errors->has('name') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('bus_ticket_name'); ?></label>
                            <div class="col-sm-8">
                                <input type="text" name="name" placeholder="<?php echo translate('placeholder_bus_ticket_name') ?>"  class="form-control">
                                <?php if($errors->has('name') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row <?php echo e($errors->has('phone') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('bus_ticket_phone'); ?></label>
                            <div class="col-sm-8">
                                <input type="text" name="phone" placeholder="<?php echo translate('placeholder_bus_ticket_phone') ?>"  class="form-control">
                                <?php if($errors->has('phone') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('phone')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row <?php echo e($errors->has('email') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('bus_ticket_email'); ?></label>
                            <div class="col-sm-8">
                                <input name="email" type="text" placeholder="<?php echo translate('placeholder_bus_ticket_email') ?>" class="form-control"> 
                                <?php if($errors->has('email') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row <?php echo e($errors->has('bus_type') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('bus_ticket_type'); ?></label>
                            <div class="col-sm-8">
                                <input name="bus_type" type="text" placeholder="<?php echo translate('placeholder_bus_ticket_type') ?>" class="form-control"> 
                                <?php if($errors->has('bus_type') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('bus_type')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row <?php echo e($errors->has('price') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('bus_ticket_price'); ?></label>
                            <div class="col-sm-8">
                                <input name="price" type="text" placeholder="<?php echo translate('placeholder_bus_ticket_price') ?>" class="form-control"> 
                                <?php if($errors->has('price') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('price')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row <?php echo e($errors->has('address') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('bus_ticket_address'); ?></label>
                            <div class="col-sm-8">
                                <input type="text" name="address" placeholder="<?php echo translate('placeholder_bus_ticket_address') ?>"  class="form-control">
                                <?php if($errors->has('address') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('address')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

						<div class="form-group row <?php echo e($errors->has('bus_gate_id') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('country'); ?></label>
                            <div class="col-sm-8">
                                <select  name="bus_gate_id" class="form-control selectpicker" data-live-search="true" placeholder="<?php echo translate('placeholder_bus_gate') ?>">
                                	<option><?php echo translate('choose_bus_gate') ?></option>
                                    <?php $__currentLoopData = $busgates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $busgate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($busgate->id); ?>"><?php echo e($busgate->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('bus_gate_id') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('bus_gate_id')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group row <?php echo e($errors->has('country') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('country'); ?></label>
                            <div class="col-sm-8">
                                <select  name="country_id" class="form-control selectpicker" data-live-search="true" placeholder="<?php echo translate('placeholder_country') ?>">
                                	<option><?php echo translate('choose_country') ?></option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                                <?php if($errors->has('country') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('country')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row <?php echo e($errors->has('state') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('state'); ?></label>
                            <div class="col-sm-8">
                                <select  name="state_id" class="form-control selectpicker" data-live-search="true" placeholder="<?php echo translate('placeholder_state') ?>">
                                	<option><?php echo translate('choose_state') ?></option>
                                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                                <?php if($errors->has('state') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('state')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row <?php echo e($errors->has('city') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('city'); ?></label>
                            <div class="col-sm-8">
                                <select  name="city_id" class="form-control selectpicker" data-live-search="true" placeholder="<?php echo translate('placeholder_city') ?>">
                                	<option><?php echo translate('choose_city') ?></option>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                                <?php if($errors->has('city') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('city')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row <?php echo e($errors->has('seat_no') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('bus_ticket_seat_no'); ?></label>
                            <div class="col-sm-8">
                                <input name="seat_no" type="text" placeholder="<?php echo translate('placeholder_bus_ticket_seat_no') ?>" class="form-control"> 
                                <?php if($errors->has('seat_no') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('seat_no')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row <?php echo e($errors->has('note') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('bus_ticket_note'); ?></label>
                            <div class="col-sm-8">
                                <input name="note" type="text" placeholder="<?php echo translate('placeholder_bus_ticket_note') ?>" class="form-control"> 
                                <?php if($errors->has('note') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('note')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row <?php echo e($errors->has('feature_photo') ? 'has-error':''); ?>">
                            <label class="col-sm-4 col-form-label"><?php echo translate('bus_ticket_feature_photo'); ?></label>
                            <div class="col-sm-8">
                                <input name="feature_photo" type="file" accept="image/png, image/jpg, image/jpef" placeholder="<?php echo translate('placeholder_bus_ticket_feature_photo') ?>" class="form-control"> 
                                <?php if($errors->has('feature_photo') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('feature_photo')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="hr-line-dashed"></div>
                        <!-- Submit Buttom -->
                        <div class="form-group row">
                            <div class="col-sm-12">
                                <span class="float-right">
                                    <a href="<?php echo e(route('busticketIndex')); ?>" class="btn btn-white"><?php echo translate('cancel'); ?></a>
                                    <button type="submit" class="btn btn-cherryhan"><?php echo translate('save') ?></button>
                                </span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cherry_han\resources\views/pages/busticket/add.blade.php ENDPATH**/ ?>