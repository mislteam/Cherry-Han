        <!-- sidebar  -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu nav-metismenu" id="side-menu">
                    <!-- Logo and Brand Name Here -->
                    <li class="nav-header">
                        <div class="dropdown logo-text bg-white">
                            <a  href="javascript:void(0)">
                                <!-- <span class="font-bold">Cherry Han</span> -->
                                <span><img alt="image" class="brand-image" src="<?php echo e(asset('images/logo/cherryhan-logo.png')); ?>"/></span>
                            </a>
                        </div>
                        <div class="logo-element bg-white">
                            <!-- Small Logo Here -->
                            <a  href="javascript:void(0)">
                                <img alt="image" class="rounded-circle brand-image" src="<?php echo e(asset('images/logo/ch-sm-logo.jpg')); ?>"/>
                            </a>
                        </div>
                    </li>
                    <!-- Logo and Brand Name End -->

                    <!-- Dashboard -->
                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['home.show'])): ?>; -->
                        <li>
                            <a href="<?php echo e(route('home')); ?>"><i class="fa fa-th-large"></i> <span class="nav-label"><?php echo translate('dashboard') ?></span></a>
                        </li>
                    <!-- <?php endif; ?> -->
                    <!-- Dashboard End -->

                    <!-- All Orders -->
                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['all-order.show'])): ?>; -->
                        <li>
                            <a href="<?php echo e(route('allorderIndex')); ?>"><i class="fa fa-th-list"></i> <span class="nav-label"><?php echo translate('all_order') ?></span></a>
                        </li>
                    <!-- <?php endif; ?> -->
                    <!-- All Orders End -->

                    <!-- Messages -->
                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['message.show'])): ?>; -->
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-comment"></i> <span class="nav-label"><?php echo translate('messages') ?></span><span class="label label-cherryhan float-right">16</span></a>
                        <ul class="nav nav-second-level collapse" >
                            <li><a href="<?php echo e(route('messageAdd')); ?>"><?php echo translate('compose_message') ?></a></li>
                            <li class="<?php echo e((Request::is('inbox*') ) ? 'active':''); ?>"><a href="<?php echo e(route('inboxmessageIndex')); ?>"><?php echo translate('inbox_message') ?> <span class="label label-cherryhan float-right">16</span></a></li>
                            <li><a href="<?php echo e(route('messageIndex')); ?>"><?php echo translate('sent_message') ?></a></li>
                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->
                    <!-- Messages End -->

                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['category.show', 'sub_category.show', 'sub_sub_category.show'])): ?>; -->
                    <!-- <?php endif; ?> -->

                    <!-- Delivery Service -->
                    <!--  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['delivery.show'])): ?>; -->
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-tasks"></i> <span class="nav-label"><?php echo translate('delivery_service') ?></span><span class="label label-cherryhan float-right">15</span></a>
                        <ul class="nav nav-second-level collapse" >
                            <li class="<?php echo e((Request::is('deliveries*') ) ? 'active':''); ?>"><a href="<?php echo e(route('deliveriesIndex')); ?>"><?php echo translate('delivery_service') ?></a></li>
                            <li class="<?php echo e((Request::is('deliverycharges*') ) ? 'active':''); ?>"><a href="<?php echo e(route('deliverychargesIndex')); ?>"><?php echo translate('delivery_charges') ?></a></li>
                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->
                    <!-- Delivery Service End -->

                    <!-- Bus Tickets Service -->
                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['bus.show', 'bus-booking.show', 'bus-gate.show'])): ?>; -->
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-bus"></i> <span class="nav-label"><?php echo translate('bus_tickets') ?></span><span class="label label-cherryhan float-right">18</span></a>
                        <ul class="nav nav-second-level collapse" >
                            <li class="<?php echo e((Request::is('bus-gate*')) ? 'active':''); ?>">
                                <a href="<?php echo e(route('busgateIndex')); ?>"><?php echo translate('busgate') ?></a>
                            </li>
                            <li class="<?php echo e((Request::is('bus-ticket*') ) ? 'active':''); ?>"><a href="<?php echo e(route('busticketIndex')); ?>"><?php echo translate('bus_tickets') ?></a></li>
                            <li class="<?php echo e((Request::is('bus-ticket-booking*') ) ? 'active':''); ?>"><a href="<?php echo e(route('busticketbookingIndex')); ?>"><?php echo translate('bus_tickets_booking') ?><span class="label label-cherryhan float-right">62</span></a></li>
                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->
                    <!-- Bus Tickets Service End -->

                    <!-- Travel & Tour Service -->
                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['tours.show', 'tours-booking', 'tours-category'], 'tours-destination')): ?>; -->
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-suitcase"></i> <span class="nav-label"><?php echo translate('travel_&_tours'); ?></span><span class="label label-cherryhan float-right">15</span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="<?php echo e(route('tourcategoryIndex')); ?>"><?php echo translate('tour_category') ?><span class="label label-ch
                             float-right">62</span></a></li>
                            <li><a href="<?php echo e(route('tourdestinationIndex')); ?>"><?php echo translate('tour_destination') ?><span class="label label-ch
                             float-right">62</span></a></li>
                            <li><a href="<?php echo e(route('tourIndex')); ?>"><?php echo translate('travel_&_tours'); ?></a></li>
                            <li><a href="<?php echo e(route('tourbookingIndex')); ?>"><?php echo translate('travel_&_tours_booking') ?><span class="label label-ch
                             float-right">62</span></a></li>
                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->
                    <!-- Travel & Tours End -->

                    <!-- Accommodation -->
                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['hotel.show', 'hotel-booking.show'])): ?>; -->
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-hotel"></i> <span class="nav-label"><?php echo translate('accommodation') ?></span><span class="label label-cherryhan float-right">16</span></a>
                        <ul class="nav nav-second-level collapse">
                            <li class="<?php echo e((Request::is('hotel*') ) ? 'active':''); ?>"><a href="<?php echo e(route('hotelIndex')); ?>"><?php echo translate('accommodation') ?></a></li>
                            <li class="<?php echo e((Request::is('hotel-booking*') ) ? 'active':''); ?>"><a href="<?php echo e(route('hotelbookingIndex')); ?>"><?php echo translate('accommodation_booking') ?><span class="label label-ch
                             float-right">16</span></a></li>
                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->

                    <!-- Cars Rental Service -->
                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['car.show', 'car-booking.show'])): ?>; -->
                    <li >
                        <a href="javascript:void(0)"><i class="fa fa-car"></i> <span class="nav-label"><?php echo translate('cars_rental') ?></span><span class="label label-cherryhan float-right">16</span></a>
                        <ul class="nav nav-second-level collapse">
                            <li class="<?php echo e((Request::is('cars*') ) ? 'active':''); ?>"><a href="<?php echo e(route('carsIndex')); ?>"><?php echo translate('cars_rental') ?></a></li>
                            <li class="<?php echo e((Request::is('cars-booking*') ) ? 'active':''); ?>"><a href="<?php echo e(route('carsbookingIndex')); ?>"><?php echo translate('cars_rental_booking') ?><span class="label label-ch
                             float-right">62</span></a></li>
                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->
                    <!-- Cars Rental Service End -->

                    <!-- Cargo Service -->
                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['cargo.show', 'cargo-booking.show'])): ?>; -->
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-truck"></i> <span class="nav-label"><?php echo translate('cargo_service') ?></span><span class="label label-cherryhan float-right">16</span></a>
                        <ul class="nav nav-second-level collapse">
                            <li class="<?php echo e((Request::is('cargo*') ) ? 'active':''); ?>"><a href="<?php echo e(route('cargoIndex')); ?>"><?php echo translate('cargo_service') ?></a></li>
                            <li><a href="<?php echo e(route('cargobookingIndex')); ?>"><?php echo translate('cargo_service_booking') ?> <span class="label label-ch
                             float-right">10</span></a></li>
                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->
                    <!-- Cargo Service End -->

                    <!-- Container Service -->
                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['container.show', 'container-booking.show'])): ?>; -->
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-truck"></i> <span class="nav-label"><?php echo translate('container_service') ?></span><span class="label label-cherryhan float-right">10</span></a>
                        <ul class="nav nav-second-level collapse">
                            <li class="<?php echo e((Request::is('container*') ) ? 'active':''); ?>"><a href="<?php echo e(route('containerIndex')); ?>"><?php echo translate('container_service') ?></a></li>
                            <li class="<?php echo e((Request::is('container-booking*'))); ?>"><a href="<?php echo e(route('containerbookingIndex')); ?>"><?php echo translate('container_service_booking') ?><span class="label label-ch
                             float-right">10</span></a></li>
                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->
                    <!-- Container Service End -->

                    <!-- Customers & Agents -->
                    <!--  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['customer.show', 'agent.show'])): ?>; -->
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-user-circle"></i> <span class="nav-label"><?php echo translate('application_users'); ?></a>
                        <ul class="nav nav-second-level collapse">
                            <li class="<?php echo e((Request::is('api-users*') ) ? 'active':''); ?>"><a href="<?php echo e(route('customerIndex')); ?>"><?php echo translate('customers') ?></a></li>
                            <li class="<?php echo e((Request::is('api-users*') ) ? 'active':''); ?>"><a href="<?php echo e(route('agentIndex')); ?>"><?php echo translate('agents') ?></a></li>
                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->
                    <!-- Customers & Agents End -->

                    <!-- Owners & Driver -->
                    <!--  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['owner.show', 'driver.show'])): ?>; -->
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-users"></i> <span class="nav-label"><?php echo translate('owners_&_drivers'); ?></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li class="<?php echo e((Request::is('car-owner*'))? 'active': ''); ?>">
                                <a href="<?php echo e(route('carownerIndex')); ?>"><?php echo translate('owners') ?></a>
                            </li>
                            <li class="<?php echo e((Request::is('car-driver*'))? 'active': ''); ?>">
                                <a href="<?php echo e(route('cardriverIndex')); ?>"><?php echo translate('drivers'); ?></a>
                            </li>
                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->
                    <!-- Owners & Driver End -->

                    <!-- Owners & Driver -->
                    <!--  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user.show'])): ?>; -->
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-users"></i> <span class="nav-label"><?php echo translate('admin_users'); ?></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li class="<?php echo e((Request::is('user*'))? 'active': ''); ?>">
                                <a href="<?php echo e(route('userIndex')); ?>"><?php echo translate('employee') ?></a>
                            </li>
                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->
                    <!-- Owners & Driver End -->

                    <!-- Business Setting -->
                    <!--  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['category.show', 'sub-category.show', 'child-categoy.show'])): ?>; -->
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-bar-chart"></i> <span class="nav-label"><?php echo translate('business_setting') ?></a>
                        <ul class="nav nav-second-level collapse">
                            <li class="<?php echo e((Request::is('banner*')) ? 'active':''); ?>">
                                <a href="<?php echo e(route('bannerIndex')); ?>"><?php echo translate('banner') ?></a>
                            </li>
                            <li class="<?php echo e((Request::is('cartype*')) ? 'active':''); ?>">
                                <a href="<?php echo e(route('cartypeIndex')); ?>"><?php echo translate('car_type') ?></a>
                            </li>
                            <li class="<?php echo e((Request::is('carbarnd*')) ? 'active':''); ?>">
                                <a href="<?php echo e(route('carbrandIndex')); ?>"><?php echo translate('car_brand') ?></a>
                            </li>
                            <li class="<?php echo e((Request::is('carmodel*')) ? 'active':''); ?>">
                                <a href="<?php echo e(route('carmodelIndex')); ?>"><?php echo translate('car_model') ?></a>
                            </li>
                            
                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->
                    <!-- Business Setting End -->

                    <!-- Setting -->
                    <!--  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['roles.show', 'permissions.show'])): ?>; -->
                    <li>
                        <a  href="javascript:void(0)"><i class="fa fa-cogs"></i> <span class="nav-label"><?php echo translate('setting') ?></a>
                        <ul class="nav nav-second-level collapse">
                            <li class="<?php echo e((Request::is('roles*'))? 'active': ''); ?>">
                                <a href="<?php echo e(route('roleIndex')); ?>"><?php echo translate('roles') ?></a>
                            </li>
                            <li class="<?php echo e((Request::is('permissions*'))? 'active': ''); ?>">
                                <a href="<?php echo e(route('permissionIndex')); ?>"><?php echo translate('permissions') ?></a>
                            </li>
                            <li class="<?php echo e((Request::is('country*'))? 'active': ''); ?>">
                                <a href="<?php echo e(route('countryIndex')); ?>"><?php echo translate('countries') ?></a>
                            </li>
                            <li class="<?php echo e((Request::is('state*'))? 'active': ''); ?>">
                                <a href="<?php echo e(route('stateIndex')); ?>"><?php echo translate('states') ?></a>
                            </li>
                            <li class="<?php echo e((Request::is('city*'))? 'active': ''); ?>">
                                <a href="<?php echo e(route('cityIndex')); ?>"><?php echo translate('cities') ?></a>
                            </li>
                            <li class="<?php echo e((Request::is('term*'))? 'active': ''); ?>">
                                <a href="<?php echo e(route('termIndex')); ?>"><?php echo translate('term_&_condition') ?></a>
                            </li>

                        </ul>
                    </li>
                    <!-- <?php endif; ?> -->
                    <!-- Setting End -->
                </ul>

            </div>
        </nav>
        <!-- sidebar End -->
<?php /**PATH D:\xampp\htdocs\cherry_han\08_04_2-22\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>