

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="ibox">
                <div class="ibox-title">
                    <h3><?php echo translate('tour_category'); ?></h3>
                    <div class="ibox-tools">
                  
                        <a href="<?php echo e(route('tourcategoryIndex')); ?>" class="btn btn-sm pt-2 btn-cherryhan" ><i class="fa fa-reply"></i><?php echo translate('back'); ?></a>
  
                    </div>
                </div>
                <div class="ibox-content">
            
                    <form action="<?php echo e(route('tourcategoryUpdate', $tourcategorys->id)); ?>" method="POST" accept-charset="utf-8" class="wizard-big">
                       
                        <?php echo csrf_field(); ?>
         
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label><?php echo translate('tour_category_name_*') ?></label>
                                        <input type="text" name="name" value="<?php echo e($tourcategorys->name); ?>" placeholder="<?php echo translate('placeholder_tour_category_name') ?>" class="form-control <?php echo e($errors->has('name') ? 'is-invalid':''); ?>" value="<?php echo e(old('name')); ?>" required>
                                        <?php if($errors->has('name') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                   
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-cherryhan float-right"><?php echo translate('save') ?></button>
                                        <a href="<?php echo e(route('tourcategoryIndex')); ?>" class="btn btn-default float-right mr-3"><?php echo translate('cancel') ?></a>
                                    </div>
                            
                                    
                                </div>
                              
                            </div>    
  
                    </form>
                </div>
            </div>
        </div>
    </div>

   
 
 <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fwsdemop/public_html/cherryhan/resources/views/pages/tourcategory/edit.blade.php ENDPATH**/ ?>