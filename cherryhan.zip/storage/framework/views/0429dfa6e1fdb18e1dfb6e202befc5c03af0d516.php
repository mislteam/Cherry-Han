<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox col-lg-6 mx-auto">
                <div class="ibox-title">
                    <h5><?php echo translate('edit_permission'); ?></h5>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('car.view')): ?>
                        <div class="ibox-tools">
                            <a href="<?php echo e(route('permissionIndex')); ?>" class="btn btn-sm pt-2 btn-cherryhan" go-to-back ><i class="fa fa-reply"></i> <?php echo translate('back'); ?></a>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="ibox-content">
                    <form action="<?php echo e(route('permissionUpdate', $permission->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row <?php echo e($errors->has('name') ? 'has-error':''); ?>">
                            <label class="col-sm-2 col-form-label"><?php echo translate('permission_name'); ?></label>
                            <div class="col-sm-10">
                                <input type="text" name="name" placeholder="<?php echo translate('placehoder_permission_name') ?>" class="form-control" value="<?php echo e(old('name', $permission->name)); ?>">
                                <?php if($errors->has('name') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group row <?php echo e($errors->has('title') ? 'has-error':''); ?>">
                            <label class="col-sm-2 col-form-label"><?php echo translate('permission_title'); ?></label>
                            <div class="col-sm-10">
                                <input type="text" name="title"  placeholder="<?php echo translate('placehoder_permission_title') ?>" class="form-control" value="<?php echo e(old('title', $permission->title)); ?>">
                                <?php if($errors->has('title') || 1): ?>
                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('title')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        

                        <div class="hr-line-dashed"></div>
                        <!-- Submit Buttom -->
                        <div class="form-group row">
                            <div class="col-sm-12">
                                <span class="float-right">
                                    <a href="<?php echo e(route('permissionIndex')); ?>" class="btn btn-white"><?php echo translate('cancel'); ?></a>
                                    <button type="submit" class="btn btn-cherryhan"><?php echo translate('save') ?></button>
                                </span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fwsdemop/public_html/cherryhan/resources/views/pages/permissions/edit.blade.php ENDPATH**/ ?>