<?php $__env->startSection('content'); ?>
    <div class="row ch-content">
        <div class="col-lg-12">

            <div class="ibox product-detail">
                <div class="ibox-title">
                    <h5><?php echo translate('cars_information'); ?></h5>
                    <div class="ibox-tools">
                        <a href="<?php echo e(route('containerIndex')); ?>" class="btn btn-sm pt-2 btn-cherryhan" go-to-back ><i class="fa fa-reply"></i> <?php echo translate('back'); ?></a>
                    </div>
                </div>
                <div class="ibox-content">
                    <?php //print_r($container->brand->name) ?>
                    <?php //print_r($container->driver->name) ?>
                    <?php //print_r($container->owner) ?>
                    <div class="row">
                        <!-- Car Feature Image and Gallery Start -->
                        <div class="col-md-5">
                            <?php $segment1 = Request::segment(1); ?>
                            <div class="product-images-<?php echo e($segment1); ?>">
                                <div>
                                    <div class="image-imitation">
                                        <img class="img-width-view" src="<?php echo e(asset('feature/container/'.$container->feature_photo)); ?>" alt="feature_photo">
                                    </div>
                                </div>
                                <?php
                                    $gallery = json_decode($container->gallery, true);
                                    foreach($gallery as $key =>$img){
                                ?>
                                    <div>
                                        <div class="image-imitation">
                                            <img class="img-width-view" src="<?php echo e(asset('gallery/container/'.$img)); ?>" alt="gallery_<?php echo e($key); ?>">
                                        </div>
                                    </div>
                                <?php }?>
                            </div>
                        </div>
                        <!-- Car Feature Image and Gallery End -->
                        <!-- Car Information -->
                        <div class="col-md-7 pl-4">

                            <h2 class="font-bold m-b-xs">
                                <?php echo e($container->name); ?>

                            </h2>
                            <hr>

                            <h4><?php echo translate('cars_information_detail') ?></h4>

                            <dl class="m-t-md">
                                <dd><b><?php echo translate('owner_name:') ?></b> <?php echo e($container->owner->name); ?></dd>
                                <dd><b><?php echo translate('owner_phone_number:') ?></b> <a href="tel:<?php echo e($container->owner->phone); ?>"><?php echo e($container->owner->phone); ?></a></dd>
                                <dd><b><?php echo translate('owner_email_address:') ?></b> <a href="mailto:<?php echo e($container->owner->email); ?>"><?php echo e($container->owner->email); ?></a></dd>
                                <dd><b><?php echo translate('owner_address:') ?></b> <?php echo e($container->owner->address); ?>, <?php echo e($container->owner->city->name); ?>, <?php echo e($container->owner->state->name); ?>, <?php echo e($container->owner->country->name); ?></dd>
                            </dl>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <dl class="small m-t-md">
                                <dt class="h4"><?php echo translate('owner_information') ?></dt>
                                <dd><b><?php echo translate('owner_name:') ?></b> <?php echo e($container->owner->name); ?></dd>
                                <dd><b><?php echo translate('owner_phone_number:') ?></b> <a href="tel:<?php echo e($container->owner->phone); ?>"><?php echo e($container->owner->phone); ?></a></dd>
                                <dd><b><?php echo translate('owner_email_address:') ?></b> <a href="mailto:<?php echo e($container->owner->email); ?>"><?php echo e($container->owner->email); ?></a></dd>
                                <dd><b><?php echo translate('owner_address:') ?></b> <?php echo e($container->owner->address); ?>, <?php echo e($container->owner->city->name); ?>, <?php echo e($container->owner->state->name); ?>, <?php echo e($container->owner->country->name); ?></dd>
                            </dl>
                        </div>
                        <div class="col-md-6">
                            <dl class="small m-t-md">
                                <dt class="h4"><?php echo translate('driver_information') ?></dt>
                                <dd><b><?php echo translate('driver_name:') ?></b> <?php echo e($container->driver->name); ?></dd>
                                <dd><b><?php echo translate('driver_phone_number:') ?></b> <a href="tel:<?php echo e($container->driver->phone); ?>"><?php echo e($container->driver->phone); ?></a></dd>
                                <dd><b><?php echo translate('driver_email_address:') ?></b> <a href="mailto:<?php echo e($container->driver->email); ?>"><?php echo e($container->driver->email); ?></a></dd>
                                <dd><b><?php echo translate('driver_address:') ?></b> <?php echo e($container->driver->address); ?>, <?php echo e($container->driver->city->name); ?>, <?php echo e($container->driver->state->name); ?>, <?php echo e($container->driver->country->name); ?></dd>
                                <dd><b><?php echo translate('driver_tours_exp:') ?></b> <?php echo e($container->driver->tour_exp); ?></dd>
                                <dd><b><?php echo translate('driver_driving_exp:') ?></b> <?php echo e($container->driver->drive_exp); ?></dd>
                                <dd><b><?php echo translate('driver_license_type:') ?></b> <?php echo e($container->driver->license_type); ?></dd>
                                <dd><b><?php echo translate('driver_drive_safety:') ?></b> <?php echo e(($container->driver->demage == 'no')? 'Yes':'No'); ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cherryhan\resources\views/pages/container/view.blade.php ENDPATH**/ ?>