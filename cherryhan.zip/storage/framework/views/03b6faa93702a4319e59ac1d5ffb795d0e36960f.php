
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="ibox">
                <div class="ibox-title">
                    <h3><?php echo translate('cargo_add')?></h3>
                    <div class="ibox-tools">
                
                        <a href="<?php echo e(route('cargoIndex')); ?>" class="btn btn-sm pt-2 btn-cherryhan" ><i class="fa fa-reply"></i><?php echo translate('back'); ?></a>
  
                    </div>
                </div>
                <div class="ibox-content">
                    
                    <form enctype="multipart/form-data" id="form" method="post" action="<?php echo e(route('cargoCreate')); ?>" class="wizard-big">
                        <?php echo csrf_field(); ?>
                        <h1 class="bg-cherryhan">Cargo Information</h1>
                        <fieldset> 
                        <input type="hidden" name="stype" id="stype" value="cargo">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group ">
                                        <clabel><?php echo translate('cargo_name_*')?></label>
                                        <input type="text" id="name" name="name" class="form-control <?php echo e($errors->has('name') ? 'is-invalid':''); ?>" value="<?php echo e(old('name')); ?>" required>
                                        <?php if($errors->has('name') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('brand_id') ? 'is-invalid':''); ?>">
                                        <label><?php echo translate('brand_name_*')?></label>
                                        <select  name="brand_id" id="brand_id" class="form-control select2_demo_1" placeholder="<?php echo app('translator')->get('form.car.brand_id.placeholder'); ?>" required>
                                            <option value=""><?php echo translate('select...')?></option>
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('brand_id') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('brand_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('model_id') ? 'is-invalid':''); ?>">
                                        <label><?php echo translate('model_name_*')?></label>
                                        <select  name="model_id" id="model_id" class="form-control select2_demo_1" placeholder="<?php echo translate('placeholder_car_model') ?>" required>
                                            <option value=""><?php echo translate('select...')?></option>
                                            
                                        </select>
                                        <?php if($errors->has('model_id') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('model_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e(($errors->has('width') || $errors->has('height') || $errors->has('length')) ? 'has-error':''); ?>">
                                        <label class="col-form-label"><?php echo translate('car_body_space_*'); ?></label>
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <input type="number" name="width" placeholder="<?php echo translate('placeholder_cargo_body_width') ?>"  class="form-control" required>
                                                <?php if($errors->has('width') || 1): ?>
                                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('width')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="number" name="height" placeholder="<?php echo translate('placeholder_cargo_body_height') ?>"  class="form-control" required>
                                                <?php if($errors->has('height') || 1): ?>
                                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('height')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="number" name="length" placeholder="<?php echo translate('placeholder_cargo_body_length') ?>"  class="form-control" required>
                                                <?php if($errors->has('length') || 1): ?>
                                                    <span class="form-text m-b-none text-danger"><?php echo e($errors->first('length')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo translate('capicity_*')?></label>
                                        <input type="text" id="capicity" name="capicity" class="form-control <?php echo e($errors->has('capicity') ? 'is-invalid':''); ?>" value="<?php echo e(old('capicity')); ?>" required>
                                        <?php if($errors->has('capicity') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('capicity')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('car_type_id') ? 'is-invalid':''); ?>">
                                        <label><?php echo translate('car_type_*')?></label>
                                        <select  name="car_type_id" class="form-control select2_demo_1" placeholder="<?php echo app('translator')->get('form.car.country_id.placeholder'); ?>" required>
                                            <option value=""><?php echo translate('select...')?></option>
                                            <?php $__currentLoopData = $car_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($cartype->id); ?>"><?php echo e($cartype->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('car_type_id') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('car_type_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                                                      
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label><?php echo translate('wheel_drive_*')?></label>
                                        <input type="text" id="wheel_drive" name="wheel_drive" class="form-control <?php echo e($errors->has('wheel_drive') ? 'is-invalid':''); ?>" value="<?php echo e(old('wheel_drive')); ?>" required>
                                        <?php if($errors->has('wheel_drive') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('wheel_drive')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                   
                                    <div class="form-group">
                                        <label><?php echo translate('license_type_*')?></label>
                                        <input type="text" id="license_type" name="license_type" class="form-control <?php echo e($errors->has('license_type') ? 'is-invalid':''); ?>" value="<?php echo e(old('license_type')); ?>" required>
                                        <?php if($errors->has('license_type') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('license_type')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="form-group <?php echo e($errors->has('country_id') ? 'is-invalid':''); ?>">
                                        <label><?php echo translate('country_*')?></label>
                                        <select  name="country_id" id="country_id" class="form-control select2_demo_1" placeholder="<?php echo translate('placeholder_country') ?>" required>
                                            <option value=""><?php echo translate('select...')?></option>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('country_id') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('country_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('state_id') ? 'is-invalid':''); ?>">
                                        <label><?php echo translate('state_*')?></label>
                                        <select  name="state_id" id="state_id" class="form-control select2_demo_1" placeholder="<?php echo app('translator')->get('form.car.state_id.placeholder'); ?>" required>
                                            <option value=""><?php echo translate('select...')?></option>
                                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('state_id') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('state_id')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group <?php echo e($errors->has('city_id') ? 'is-invalid':''); ?>">
                                        <label><?php echo translate('city_*')?></label>
                                        <select  name="city_id" id="city_id" class="form-control select2_demo_1" placeholder="<?php echo app('translator')->get('form.car.city_id.placeholder'); ?>" required>
                                            <option value=""><?php echo translate('select...')?></option>
                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('city_id') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('city_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                                                                                 
                                </div>                               
                            </div>
                           
                        </fieldset>
                    <!-- </form>

 -->                    
                        <h1 class="bg-cherryhan">Services </h1>
                        <fieldset>
                            <div class="row">
                                <div class="col-lg-12">
                                    <!--  -->
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th><span class="text-right text-muted text-small">Services *</span></th>
                                                <!-- <th>Value <span class="text-right text-muted text-small">Service name</span></th> -->
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody id="kpi-setdata">
                                            <tr>
                                                <td class="col-lg-6">
                                                    <input class="form-control " name="service[]" value="" type="text" placeholder="Service (eg. Fuel: Diesel)" required>
                                                </td>
                                                <!-- <td class="col-lg-6">
                                                    <input class="form-control" name="kpivalue[]" value="" type="text" placeholder="Service name">
                                                </td> -->
                                                <td class="col-lg-2">
                                                    <span class=" btn btn-cherryhan fa fa-trash-o text-danger" misl-add-removes></span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-lg-12">
                                    <div class="text-center">
                                        <div class="btn btn-cherryhan" style="margin-top: 10px">
                                            <span class="pvb_ddn-text" misl-add-rows="#kpi-setdata"><i class="fa fa-plus-circle"></i> Add New Row</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                   
                        
                        <h1 class="bg-cherryhan">Owner Driver Information</h1>
                        <fieldset>
                            <div class="text-center">
                                <!-- <h2>You did it Man :-) style="margin-top: 120px"</h2> -->
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">                                         
                                            <select  name="ownner_id" id="owner_id" class="form-control" placeholder="<?php echo app('translator')->get('form.car.owner_id.placeholder'); ?>">
                                                <?php $__currentLoopData = $ownners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($owner->id); ?>"><?php echo e($owner->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                        
                                        <select  name="driver_id" id="driver_id" class="form-control" placeholder="<?php echo app('translator')->get('form.car.driver_id.placeholder'); ?>">
                                            <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($driver->id); ?>"><?php echo e($driver->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </fieldset>

                        <h1 class="bg-cherryhan"><?php echo translate('feature_photo_&_gallery') ?></h1>
                        <fieldset>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo app('translator')->get('cruds.car.feature_photo.label'); ?> *</label>
                                        <input type="file" id="feature_photo" name="feature_photo" class="form-control <?php echo e($errors->has('feature_photo') ? 'is-invalid':''); ?>" value="<?php echo e(old('feature_photo')); ?>" required>
                                        <?php if($errors->has('feature_photo') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('feature_photo')); ?></span>
                                        <?php endif; ?>
                                    </div>  
                                    <div class="form-group">
                                        <label><?php echo app('translator')->get('cruds.car.gallery.label'); ?> *</label>
                                        <input type="file" multiple name="gallery[]" class="form-control <?php echo e($errors->has('gallery') ? 'is-invalid':''); ?>" value="<?php echo e(old('gallery')); ?>" required>
                                        <?php if($errors->has('gallery') || 1): ?>
                                            <span class="error invalid-feedback"><?php echo e($errors->first('gallery')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6"></div>
                            </div>
                            
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>

   
 
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fwsdemop/public_html/cherryhan/resources/views/pages/cargo/add.blade.php ENDPATH**/ ?>