
<?php $__env->startSection('content'); ?>

<section class="jumbotron text-center">
    <div class="container mb-4">
      <h3><b>Hotel</b></h3>
     
    </div>
  </section>
<h3 style="text-align: left;margin-top: 10px;"><b>Hotel</b></h3>
<div class="content">   
        <div class="row">
            <?php 
                foreach($hotels as $row){
            ?>
            <div class="col-md-3">
                <!-- <div class="card shadow-lg p-3 mb-5 bg-white rounded"> -->
                <div class="card" style="box-shadow: 0 0 40px 0 rgba(100, 100, 100, 0.26) !important;">
                    <a href="<?php echo e(route('frontendhotelView', $row->id)); ?>" class="">
                      <img class="card-img-top" src="<?php echo e(asset('feature/hotel/'.$row->feature_image)); ?>" alt="Card image cap">
                      <div class="card-body">
                        <p class="card-title"></p>

                        <p class="card-text"><?php echo e($row->name); ?></p>
                        <p class="card-text"><?php echo e($row->price); ?></p>
                        
                      </div>
                    </a> 
                </div>               
            </div>
        <?php } ?>
           
        </div>        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cherry_han\resources\views/frontend/hotel.blade.php ENDPATH**/ ?>