        <?php $__env->startSection('content'); ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5><?php echo translate('car_brand_list'); ?></h5>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('car.add')): ?>
                                <div class="ibox-tools">
                                    <a href="<?php echo e(route('carbrandAdd')); ?>" class="btn btn-sm pt-2 btn-cherryhan" ><i class="fa fa-plus-circle"></i> <?php echo translate('add_new'); ?></a>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="ibox-content">
                            <?php $segment1 = Request::segment(1); ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover dataTables-<?php echo e($segment1); ?>" >
                                    <thead>
                                        <tr>
                                            <th class="text-center"><?php echo translate('id') ?></th>
                                            <th class="text-center"><?php echo translate('brand_name') ?></th>
                                            <th class="text-center"><?php echo translate('seo_title') ?></th>
                                            <th class="text-center"><?php echo translate('action') ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $count = 1;
                                    ?>
                                    <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carbrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-right"><?php echo e($count); ?></td>
                                            <td><?php echo e($carbrand->name); ?></td>
                                            <td><?php echo e($carbrand->seo_title); ?></td>
                                            <td class="text-center">
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('car.delete')): ?>
                                                <form action="<?php echo e(route('carbrandDestroy', $carbrand->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="btn-group">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('car.edit')): ?>
                                                            <a href="<?php echo e(route('carbrandEdit', $carbrand->id)); ?>" type="button" class="btn btn-info btn-sm pt-2"> <?php echo translate('edit') ?></a>
                                                        <?php endif; ?>
                                                        <input name="_method" type="hidden" value="DELETE">
                                                        <button type="button" class="btn btn-danger btn-sm pt-2" onclick="if (confirm('<?php echo translate('are_you_sure?') ?>')) { this.form.submit() } "> <?php echo translate('delete') ?></button>
                                                    </div>
                                                </form>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php
                                        $count++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cherry_han\resources\views/pages/carbrand/index.blade.php ENDPATH**/ ?>