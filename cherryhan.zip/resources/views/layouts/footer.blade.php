			<div class="footer ch-footer">
                <div class="float-right">
                    <i><?php echo translate('developed_by'); ?> <a href="https://myanmarictsolutions.pro/" class="misl"><strong><?php echo translate('misl') ?></strong></a> </i>
                </div>
                <div>
                	<strong>Copyright</strong> &copy; {{ date('Y') }} <a href="https://t.me/" class="cherryhan chfw-6"><?php echo translate('cherry_han') ?> </a>All rights reserved.
                </div>
            </div>