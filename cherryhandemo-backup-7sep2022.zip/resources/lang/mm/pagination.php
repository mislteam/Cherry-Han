<?php

return [
    'previous' => '&laquo;',
    'next'     => '&raquo;',
    'total_items' => 'Total Items'
];
