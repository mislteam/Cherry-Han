<?php

return [
    'site_title' => 'Alpha Web Software',
];
