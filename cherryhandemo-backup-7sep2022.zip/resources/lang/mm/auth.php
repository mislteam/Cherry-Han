<?php

return [
    'failed'   => 'User with such data was not found',
    'throttle' => 'Too many login attempts, please try again in: seconds seconds',
];
