@extends('layouts.frontend_template')
@section('content')

<div class="">   
        <div class="row mt-5">
               <div class="col-md-2"></div>               
	               <div class="col-md-8">
	                  <h4 class="mt-5 text-center">Order Received</h4><br>
                         <p> သင်၏ အမှာစာအားလက်ခံရရှိပါသည်။ 
မကြာမီ အချိန်အတွင်းကုမ္ပဏီမှ ဆက်သွယ်အကြောင်းကြားပေးပါမည်။ 
မိတ်ဆွေ၏ပစ္စည်းများကိုလာရောက်ယူဆောင်ပြီး စိတ်တိုင်းကျ ဝန်ဆောင်မှုပေးပါမည်။</p>
                         <div class="text-center">
                            <button class="btn btn-primary">New Order</button> 
                            <button class="btn btn-primary mr-3">My Account</button>  
                         </div>
	               </div>  
                                   
               <div class="col-md-2"></div>              
           
        </div>        
    </div>

 @endsection